const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    try {

        //Récupération du token
        // La constante token réqupère uniquement le token de la requête
        const token = req.headers.authorization.split(" ")[1]
        console.log("-------------------------AUTHENTIFICATION-------------------------")
        console.log("token")
        console.log(token)

        //décoder le token
        const decodedToken = jwt.verify(token, 'RANDOM_TOKEN_ACCESS')
        console.log("decodedToken")
        console.log(decodedToken)
        //Récupération de l'id du token et le comparer avec l'id en clair
        const userId = decodedToken.userId

        req.auth = {
            userId: userId
        };
        
        console.log(req.body);

        next()
        /*console.log("req.originalUrl");
        console.log(req.originalUrl);

        userIdParamsUrl = req.originalUrl.split("=")[1];
        console.log("afichage de l'id");
        console.log(userIdParamsUrl);
        console.log(userId);

        //Comparaison des deux ids

        // Si on utilise le champs 'raw' (pas d'envoie d'image)
        if(req._body === true){
            console.log("req._body : TRUE");
            if(req.body.userId === userId){
            next();
            } else {
                console.log("erreur authentification body raw");
                throw "erreur identification userId raw";
            }

        // Si l'userId du form-data est égal à celui du token décodé(envoie d'image avec multer)
        } else if(userIdParamsUrl === userId) {
            console.log("userIdParamsUrl === userId(decodedToken)")
            next();

        } else {
            throw "erreur identification userId form-data";
        } */

    } catch (error) {
        res.status(403).json({ error}); 
    } 
};